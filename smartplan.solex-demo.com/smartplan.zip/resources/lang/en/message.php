<?php

return ['welcome_msg'=>"welcome to php step by step"];

?>
