<?php

return ['welcome_msg'=>"वागत है php स्टेप बाय स्टेप"];

?>
