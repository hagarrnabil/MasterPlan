<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Babylon Example</title>

<!-- 
<script src="https://cdn.babylonjs.com/babylon.js"></script>
<script src="https://cdn.babylonjs.com/loaders/babylonjs.loaders.min.js"></script>

<script src="https://cdn.babylonjs.com/loaders/babylon.objFileLoader.js"></script>

<script src="https://preview.babylonjs.com/babylon.js"></script>
<script src="https://preview.babylonjs.com/loaders/babylonjs.loaders.min.js"></script> -->


        
    </head>
    <body>
    <canvas id="renderCanvas" touch-action="none" width="1000px" height="500px"></canvas> <!-- touch-action="none" for best results from PEP -->



    <!-- <script src="BabylonJs/babylon.custom.js"></script> -->
    <script src="https://cdn.babylonjs.com/babylon.js"></script>
    <script src="https://cdn.babylonjs.com/loaders/babylonjs.loaders.min.js"></script>

<script>
// After that, we create our scene. In order to keep your program compatible with the Babylon.js Playground, we recommend that you insert a "createScene" function at this point. Beside generating a Babylon Scene Object, createScene() is where you will add your basic scene requirements: a camera, a light, and two basic meshes (a sphere and a ground plane).
var createScene = function (canvasID, path, name) {

  // The first step is to get the reference of the canvas element from our HTML document:
  var canvas = document.getElementById(canvasID);

  // Then, load the Babylon 3D engine:
  var engine = new BABYLON.Engine(canvas, true);

  // This creates a basic Babylon Scene object (non-mesh)
  var scene = new BABYLON.Scene(engine);
  scene.color=new BABYLON.Color3(1, 1, 1);

  var light = new BABYLON.HemisphericLight("light1", new BABYLON.Vector3(1, 1, 0), scene);
  light.intensity = 3.0;
  light.specular = new BABYLON.Color3(0.0, 0.0, 0.0);

  var cam = new BABYLON.ArcRotateCamera("ArcRotateCamera", 0.0, 1.0, 60, new BABYLON.Vector3(0, 10, 0), scene);
  cam.attachControl(canvas, false, false);
  cam.lowerRadiusLimit = 0.01;

  var loader = new BABYLON.AssetsManager(scene);
  var obj = loader.addMeshTask("default", "", path, name);

  loader.onFinish = function () {
    engine.runRenderLoop(function () {
      scene.render();
    });
  };
  loader.load();
  // The next three javascript lines are very important, as they register a render loop to repeatedly render the scene on the canvas:
  engine.runRenderLoop(function () {
    scene.render();
  });

  var currentMesh;
            var onclick = function (evt) {

                if (evt.button !== 0) {
                    return;
                }

                // check if we are under a mesh
                var pickInfo = scene.pick(scene.pointerX, scene.pointerY, function (mesh) {
                    return mesh;
                });
                if (pickInfo.hit) {
                    currentMesh = pickInfo.pickedMesh;
                    currentMesh.isVisible=!currentMesh.isVisible;
                }
            };


            canvas.addEventListener("dblclick", onclick, false);

            scene.onDispose = function () {
                canvas.removeEventListener("dblclick", onclick);

            };

  scene.executeWhenReady(function ()
  {
    var parts = scene.meshes;
    var temp = "";
    for (var i = 0; i < parts.length; i++)
    {
      if (!parts[i].name.startsWith("_mm"))
      {
        temp = parts[i].name;
      } else
      {
        parts[i].name = temp + "$" + parts[i].name;
      }
    }
  });

  // Lastly, you should implement a little canvas/window resize event handler, like this:
  window.addEventListener('resize', function () {
    engine.resize();
  });
  return scene;
};
</script>
<script>
var scene = createScene("renderCanvas", "assets/city/", "city.obj");
</script>

  <script type="text/javascript">
  function full_screen()
  {
    // check if user allows full screen of elements. This can be enabled or disabled in browser config. By default its enabled.
    //its also used to check if browser supports full screen api.
    if("fullscreenEnabled" in document || "webkitFullscreenEnabled" in document || "mozFullScreenEnabled" in document || "msFullscreenEnabled" in document)
    {
      if(document.fullscreenEnabled || document.webkitFullscreenEnabled || document.mozFullScreenEnabled || document.msFullscreenEnabled)
      {
        console.log("User allows fullscreen");

        var element = document.getElementById("divRender");
        //requestFullscreen is used to display an element in full screen mode.
        if("requestFullscreen" in element)
        {
          element.requestFullscreen();
        }
        else if ("webkitRequestFullscreen" in element)
        {
          element.webkitRequestFullscreen();
        }
        else if ("mozRequestFullScreen" in element)
        {
          element.mozRequestFullScreen();
        }
        else if ("msRequestFullscreen" in element)
        {
          element.msRequestFullscreen();
        }

      }
    }
    else
    {
      console.log("User doesn't allow full screen");
    }
  }

  function screen_change()
  {
    //fullscreenElement is assigned to html element if any element is in full screen mode.
    if(document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement)
    {
      console.log("Current full screen element is : " + (document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement))
    }
    else
    {
      // exitFullscreen us used to exit full screen manually
      if ("exitFullscreen" in document)
      {
        document.exitFullscreen();
      }
      else if ("webkitExitFullscreen" in document)
      {
        document.webkitExitFullscreen();
      }
      else if ("mozCancelFullScreen" in document)
      {
        document.mozCancelFullScreen();
      }
      else if ("msExitFullscreen" in document)
      {
        document.msExitFullscreen();
      }
    }
  }

  //called when an event goes full screen and vice-versa.
  document.addEventListener("fullscreenchange", screen_change);
  document.addEventListener("webkitfullscreenchange", screen_change);
  document.addEventListener("mozfullscreenchange", screen_change);
  document.addEventListener("MSFullscreenChange", screen_change);

  //called when requestFullscreen(); fails. it may fail if iframe don't have allowfullscreen attribute enabled or for something else.
  document.addEventListener("fullscreenerror", function(){console.log("Full screen failed");});
  document.addEventListener("webkitfullscreenerror", function(){console.log("Full screen failed");});
  document.addEventListener("mozfullscreenerror", function(){console.log("Full screen failed");});
  document.addEventListener("MSFullscreenError", function(){console.log("Full screen failed");});
</script>
    

    </body>
</html>
