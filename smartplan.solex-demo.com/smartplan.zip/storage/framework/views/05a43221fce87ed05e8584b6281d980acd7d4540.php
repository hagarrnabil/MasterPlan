<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>OBJ File</title>
<style>
body,html{width:100%;height:100%;padding:0;margin:0;overflow: hidden;}
</style>


<script src="threeJS/build/three.min.js"></script>

		<script src="threeJS/examples/js/controls/TrackballControls.js"></script>
		<script src="threeJS/examples/js/effects/AsciiEffect.js"></script>

		<script src="threeJS/examples/js/renderers/*"></script>
        <script src="threeJS/examples/js/loaders/OBJLoader.js"></script>

		

		<script src="threeJS/examples/js/libs/stats.min.js"></script>
        
    </head>
    <body>
<!-- My scene -->
<canvas id="scene"></canvas>

<!--
  I created a collection of small examples in Three.js to understand very quickly the purpose of some functions.
  You can visit the 'website' of the entire collection of pens here : http://mamboleoo.be/learnThree/

  You can also see the collection in CodePen
  https://codepen.io/collection/DrxLEd/

  Do not hesitate to comment if there is something wrong (I'm still learning)

  Thanks !
-->

<script>
//This demo is using the plugin "OBJLoader". Don't forget to include it into your page ;)
//You can find it here : https://github.com/mrdoob/three.js/tree/cf584a60bdfd24c42eaa81d484533364742bda44/examples/js/loaders

var renderer, scene, camera, banana;

var ww = window.innerWidth,
	wh = window.innerHeight;

function init(){

	renderer = new THREE.WebGLRenderer({canvas : document.getElementById('scene')});
	renderer.setSize(ww,wh);

	scene = new THREE.Scene();

	camera = new THREE.PerspectiveCamera(50,ww/wh, 0.1, 10000 );
	camera.position.set(0,0,500);
	scene.add(camera);

	//Add a light in the scene
	directionalLight = new THREE.DirectionalLight( 0xffffff, 0.8 );
	directionalLight.position.set( 0, 0, 350 );
	directionalLight.lookAt(new THREE.Vector3(0,0,0));
	scene.add( directionalLight );

	//Load the obj file
	loadOBJ();
}

var loadOBJ = function(){

	//Manager from ThreeJs to track a loader and its status
	var manager = new THREE.LoadingManager();
	//Loader for Obj from Three.js
	var loader = new THREE.OBJLoader( manager );
  
	//Launch loading of the obj file, addBananaInScene is the callback when it's ready 
	loader.load( 'https://s3-us-west-2.amazonaws.com/s.cdpn.io/127738/banana.obj', addBananaInScene);

};

var addBananaInScene = function(object){
	banana = object;
	//Move the banana in the scene
	banana.rotation.x = Math.PI/2;
	banana.position.y = -200;
	banana.position.z = 50;
	//Go through all children of the loaded object and search for a Mesh
	object.traverse( function ( child ) {
		//This allow us to check if the children is an instance of the Mesh constructor
		if(child instanceof THREE.Mesh){
			child.material.color = new THREE.Color(0xffffff);//0X00FF00
			//Sometimes there are some vertex normals missing in the .obj files, ThreeJs will compute them
			child.geometry.computeVertexNormals();
		}
	});
	//Add the 3D object in the scene
	scene.add(banana);
	render();
};


var render = function () {
	requestAnimationFrame(render);

	//Turn the banana
	banana.rotation.z += .01;

	renderer.render(scene, camera);
};

init();
</script>
    </body>
</html>
