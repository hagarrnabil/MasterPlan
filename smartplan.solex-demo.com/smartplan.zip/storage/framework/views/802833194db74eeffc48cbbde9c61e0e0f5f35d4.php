<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Cad Viewer</title>

		<!-- JQUERY AND BOOTSTARB  -->
		<!-- <script src="cadviewer/app/js/jquery-3.2.1.js" type="text/javascript"></script>
	<script src="cadviewer/app/js/jquery.qtip.min.js" type="text/javascript"></script>
	<script src="cadviewer/app/js/jquery-ui-1.11.4.min.js" type="text/javascript"></script>
	
	
	<script src="cadviewer/app/js/popper.js" type="text/javascript" ></script>


	<script src="cadviewer/app/js/bootstrap.min.js" type="text/javascript"></script> -->
		<!-- --------------------------- -->


		<!-- CADVIEWER JS  -->
	<!-- <script src="cadviewer/app/js/cadviewerjs.min.js" type="text/javascript" ></script> -->
		<!-- <script src="cadviewer/app/js/cadviewerjs_setup_min.js" type="text/javascript" ></script> -->
		<!-- <script src="cadviewer/app/js/cvjs_api_styles_2_0_26.js" type="text/javascript" ></script>

		<script src="cadviewer/app/js/snap.svg-min.js" type="text/javascript" ></script>

		<script src="cadviewer/app/js/rgbcolor.js" type="text/javascript" ></script>
		<script src="cadviewer/app/js/StackBlur.js" type="text/javascript" ></script>
		<script src="cadviewer/app/js/canvg.js" type="text/javascript" ></script> -->
		<!-- ---------------------------- -->

<!-- 	
	<link href="cadviewer/app/css/cvjs_4.1.0.css" media="screen" rel="stylesheet" type="text/css" />
	<link href="cadviewer/app/css/bootstrap.min.css" media="screen" rel="stylesheet" type="text/css" />

	<link href="cadviewer/app/css/jquery-ui-1.11.4.min.css" media="screen" rel="stylesheet" type="text/css" />
	<link href="cadviewer/app/css/jquery.qtip.min.css" media="screen" rel="stylesheet" type="text/css" /> -->














	<script src="cadviewer/app/js/jquery-2.2.3.js" type="text/javascript"></script>
	<script src="cadviewer/app/js/jquery.qtip.min.js" type="text/javascript"></script>
	<link href="cadviewer/app/css/jquery.qtip.min.css" media="screen" rel="stylesheet" type="text/css" />

	<script src="cadviewer/app/js/popper.js" type="text/javascript"></script>

	<script src="cadviewer/app/js/bootstrap.min.js" type="text/javascript"></script>
	<link href="cadviewer/app/css/bootstrap.min.css" media="screen" rel="stylesheet" type="text/css" />

	<script src="cadviewer/app/js/jquery-ui-1.11.4.min.js" type="text/javascript"></script>
	<link href="cadviewer/app/css/jquery-ui-1.11.4.min.css" media="screen" rel="stylesheet" type="text/css" />

	<script src="cadviewer/app/js/cadviewerjs.min.js" type="text/javascript" ></script>

	<link href="cadviewer/app/css/cvjs_4.1.0.css" media="screen" rel="stylesheet" type="text/css" />
	<link href="cadviewer/app/css/layerlist_05.css" media="screen" rel="stylesheet" type="text/css" />

	<script src="cadviewer/app/js/library_js_svg_path.js" type="text/javascript"></script>			
	<script src="cadviewer/app/js/snap.svg-min.js" type="text/javascript" ></script>

	<script src="cadviewer/app/js/axuploader_2_19.js" type="text/javascript" ></script>
	<script src="cadviewer/app/js/cvjs_api_styles_2_0_26.js" type="text/javascript" ></script>
	<script type="text/javascript" src="cadviewer/app/js/rgbcolor.js"></script>
	<script type="text/javascript" src="cadviewer/app/js/StackBlur.js"></script>
	<script type="text/javascript" src="cadviewer/app/js/canvg.js"></script>
	<script src="cadviewer/app/js/list.js" type="text/javascript"></script>
	<script src="cadviewer/app/js/jscolor.js"></script>
	<link href="cadviewer/app/css/loading_animation_2.css" rel="stylesheet">
	
	<script src="cadviewer/app/js/jstree/jstree.min.js"></script>
	<script src="cadviewer/app/js/xml2json.min.js"></script>
		
	<script src="./CV-JS_ServerSettings.js" type="text/javascript"></script>

	
<!--	<script src="./CV-JS_ServletHandlerSettings.js" type="text/javascript"></script> -->
<!--	<script src="./CV-JS_AshxhandlerSettings.js" type="text/javascript"></script> -->

	





    </head>
    <body>

	<!-- <svg id="floorPlan"  style="border:0px none;width:1000;height:800;">
		</svg> -->

		<div id="floorPlan"  style="border:0px none;width:1000;height:800;">
		</div>

		<div id="tip"></div>

		<div id="wait_looper"></div>
		<canvas id="floorPlanCanvasObject" width="10" height="10"></canvas>

		<!-- <div id="gMenu"  style="float:left;clear:none;margin-top:30px;margin-left:20px;" >
		</div> -->

		<!-- <map name="PanZoomMap" >
			<area shape="rect" alt="" title="Zoom Extents" coords="16,6,69,58" href="javascript:cvjs_resetZoomPan();"/>
			<area shape="rect" alt="" title="Zoom In" coords="16,66,69,115" href="javascript:cvjs_zoomIn();"/>
			<area shape="rect" alt="" title="Zoom Out" coords="16,116,69,161" href="javascript:cvjs_zoomOut();"/>
			<area shape="rect" alt="" title="Zoom Window" coords="16,162,69,210" href="javascript:cvjs_zoomWindow();"/>
			<area shape="rect" alt="" title="Load Last Page" coords="16,220,69,255" href="javascript:cvjs_lastPage();"/>
			<area shape="rect" alt="" title="Load Next Page" coords="16,256,69,289" href="javascript:cvjs_nextPage();"/>
			<area shape="rect" alt="" title="Load Previous Page" coords="16,290,69,324" href="javascript:cvjs_previousPage();"/>
			<area shape="rect" alt="" title="Load First Page" coords="16,325,69,360" href="javascript:cvjs_firstPage();"/>
	</map> -->


		<script>
		// if (!isSmartPhoneOrTablet)
		// 	$('#gMenu').html("<img src=\"../images/PanZoomFull.png\" usemap=\"#PanZoomMap\" border=\"0\" height=\"267\" width=\"79\" class=\"map\" hidefocus=\"true\">");
		// else
		// 	$('#gMenu').html("<img src=\"../images/ZoomExtentsDevice.png\" usemap=\"#ZoomExtentsDeviceMap\" border=\"0\" height=\"176\" width=\"79\" class=\"map\" hidefocus=\"true\">")

	// $('#gMenu').html("<img src=\"../images/PanZoomWindowFullPages7t.png\" usemap=\"#PanZoomMap\" border=\"0\" height=\"363\" width=\"78\" class=\"map\" hidefocus=\"true\">");

	$(document).ready(function(){
		// Initalize CADViewer JS, referencing a svg div with id "floorplan" and no attributes controls
		cvjs_InitCADViewerJS("floorPlan");


		// // Open a drawing instance
		var FileNameUrl = "cadviewer/content/drawings/dwg/1st floor lighting.dwg";//http://creator.vizquery.com/City_map.dwg
		var FileNameUrlNoExtension = "City_base_map";

		// cvjs_LoadDrawing_Conversion("floorPlan", FileNameUrl, FileNameUrlNoExtension , "", "");
		cvjs_LoadDrawing("floorPlan", FileNameUrl );
		

	});

	$(window).resize(function() {
		cvjs_windowResize_position(true, "floorPlan" );
	});


	function cvjs_ObjectSelected(rmid){
		// rmid : ID of the object clicked
		// generic callback method when room object has been clicked

		// fill in your own stuff here, API REST calls to get information about the object, do your specific highlight, etc.
		// this method MUST be retained as a dummy method! - if not implemeted -
	}


// generic callback method, called when drawing or page is fully loaded
function cvjs_OnLoadEnd(){
			// generic callback method, called when the drawing is loaded
			// here you fill in your stuff, call DB, set up arrays, etc..
			// this method MUST be retained as a dummy method! - if not implemeted -

			cvjs_resetZoomPan();

	}	

		</script>

    </body>
</html>
