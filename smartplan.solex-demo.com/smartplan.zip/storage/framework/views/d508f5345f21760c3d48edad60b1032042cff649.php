<html>
    <head>
        <title>Unit Details</title>
        <style>
           *{
                font-family: sans-serif; /* Change your font family */
            }
            .content-table {
                border-collapse: collapse;
                margin: 25px 0;
                font-size: 0.9em;
                min-width: 400px;
                border-radius: 5px 5px 0 0;
                overflow: hidden;
                box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
                width: 100%;
                /* height: 80%; */
                
            }
            .content-table thead tr {
                background-color: #009879;
                color: #ffffff;
                text-align: left;
                font-weight: bold;
            }
            .content-table th, .content-table td {
                padding: 12px 15px;
            }
            .content-table tbody tr {
                border-bottom: 1px solid #dddddd;
            }
            .content-table tbody tr:nth-of-type(even) {
                background-color: #f3f3f3;
            }
            .content-table tbody tr:last-of-type {
                border-bottom: 2px solid #009879;
            }
            .content-table tbody tr:hover {
                /*font-weight: bold;*/
                color: #009879;
            }
            .Unit_Link{
                text-align: right;
                text-decoration: none;
                color: #009879;
                font-weight: bold;
            }
            .Back_Home{
                text-align: center;
                text-decoration: none;
                color: #009879;
                font-weight: bold;
            }
        </style>
    </head>
    <body>
        <table class="content-table">
            <thead>
                <tr>
                    <th>Unit</th>
                    <th>Name</th>
                    <th>price $</th>
                    <th>View</th>
                    <th>Floor</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $index = 1 ; ?>
                <tr>
                    <td><?php echo e($index); ?></td>
                    <td><a href="<?php echo e(url('/unit_details')); ?>/<?php echo e($unit->unitNumber); ?>" class="Unit_Link"><?php echo e($unit->unitNumber); ?></a></td>
                    <td><?php echo e($unit->priceAmount); ?></td>
                    <td><?php echo e($unit->description); ?></td>
                    <td><?php echo e($unit->floor); ?></td>
                </tr>
                <?php $index++ ; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- <tr>
                    <td>2</td>
                    <td><a href="<?php echo e(url('/unit_details')); ?>" class="Unit_Link">U-12</a></td>
                    <td>72,400</td>
                    <td>Pool View</td>
                    <td>4</td>
                </tr>
                <tr>
                    <td>3</td>
                    <td><a href="<?php echo e(url('/unit_details')); ?>" class="Unit_Link">U-13</a></td>
                    <td>52,300</td>
                    <td>Lake View</td>
                    <td>3</td>
                </tr>
                <tr>
                    <td>4</td>
                    <td><a href="<?php echo e(url('/unit_details')); ?>" class="Unit_Link">U-14</a></td>
                    <td>42,380</td>
                    <td>Pool View</td>
                    <td>2</td>
                </tr>
                <tr>
                    <td>5</td>
                    <td><a href="<?php echo e(url('/unit_details')); ?>" class="Unit_Link">U-17</a></td>
                    <td>77,300</td>
                    <td>Pool View</td>
                    <td>5</td>
                </tr> -->
            </tbody>
          </table>
          <p class="Back_Home"><a href="<?php echo e(url('/')); ?>" class="Back_Home"> Back To Home Page </a></p>
          
    </body>
</html>
